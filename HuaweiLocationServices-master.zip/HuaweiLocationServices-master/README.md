# Huawei Location Services
Huawei Mobile Services - Location Services
You can find Fused Location, Geofence, Activity Recognition samples in this demo application.
